const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');

userInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
});

sendBtn.addEventListener('click', handleUserMessage);
userInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleUserMessage();
    }
});

function handleUserMessage() {
    const text = userInput.value.trim();
    if (text === '') return;

    appendMessage(text, 'user');
    userInput.value = '';
    userInput.style.height = 'auto';

    setTimeout(() => {
        generateAIResponse(text);
    }, 600);
}

function appendMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);

    const avatarDiv = document.createElement('div');
    avatarDiv.classList.add('message-avatar');
    avatarDiv.innerHTML = sender === 'ai' ? '<i class="fa-solid fa-robot"></i>' : '<i class="fa-solid fa-user"></i>';

    const contentDiv = document.createElement('div');
    contentDiv.classList.add('message-content');
    
    const p = document.createElement('p');
    p.textContent = text;
    contentDiv.appendChild(p);

    messageDiv.appendChild(avatarDiv);
    messageDiv.appendChild(contentDiv);
    chatMessages.appendChild(messageDiv);

    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function generateAIResponse(userText) {
    let reply = `"${userText}" ile ilgili belirttiğiniz konuyu inceledim. HTML, CSS ve JavaScript projelerinde bu tür yapılar oldukça popülerdir. Size başka hangi konuda yardımcı olabilirim?`;
    
    if (userText.toLowerCase().includes('merhaba') || userText.toLowerCase().includes('selam')) {
        reply = 'Merhaba! Bugün kodlama veya başka bir konuda size nasıl destek olbilirim?';
    } else if (userText.toLowerCase().includes('yardım')) {
        reply = 'Elbette, projenizde takıldığınız bir yer varsa kodları inceleyebilir veya yeni fikirler üretebilirim.';
    }

    appendMessage(reply, 'ai');
}
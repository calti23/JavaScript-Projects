// Örnek Veri (Kişiler ve Mesajlaşma Geçmişi)
const contacts = [
    {
        id: 1,
        name: "Ayşe Demir",
        avatar: "https://i.pravatar.cc/150?img=1",
        status: "Çevrimiçi",
        messages: [
            { sender: "received", text: "Merhaba! Proje nasıl gidiyor?", time: "10:42" },
            { sender: "sent", text: "Harika gidiyor, arayüzü bitirmek üzereyim.", time: "10:44" }
        ]
    },
    {
        id: 2,
        name: "Mehmet Kaya",
        avatar: "https://i.pravatar.cc/150?img=3",
        status: "Son görülme 11:15",
        messages: [
            { sender: "received", text: "Toplantı saat kaçta?", time: "09:30" }
        ]
    },
    {
        id: 3,
        name: "Zeynep Çelik",
        avatar: "https://i.pravatar.cc/150?img=5",
        status: "Çevrimiçi",
        messages: [
            { sender: "received", text: "Dosyaları kontrol ettin mi?", time: "Dün" }
        ]
    }
];

let activeContactId = 1; 

const chatListEl = document.getElementById("chatList");
const chatMessagesEl = document.getElementById("chatMessages");
const chatFormEl = document.getElementById("chatForm");
const messageInputEl = document.getElementById("messageInput");
const activeUserNameEl = document.getElementById("activeUserName");
const activeUserAvatarEl = document.getElementById("activeUserAvatar");
const activeUserStatusEl = document.getElementById("activeUserStatus");
const searchInputEl = document.getElementById("searchInput");

// Sohbet Listesini Ekrana Bas
function renderChatList(filterText = "") {
    chatListEl.innerHTML = "";
    
    const filteredContacts = contacts.filter(c => 
        c.name.toLowerCase().includes(filterText.toLowerCase())
    );

    filteredContacts.forEach(contact => {
        const lastMsg = contact.messages[contact.messages.length - 1] || { text: "" };
        
        const chatItem = document.createElement("div");
        chatItem.classList.add("chat-item");
        if (contact.id === activeContactId) {
            chatItem.classList.add("active");
        }

        chatItem.innerHTML = `
            <img src="${contact.avatar}" alt="${contact.name}">
            <div class="chat-info">
                <h4>${contact.name}</h4>
                <p>${lastMsg.text}</p>
            </div>
        `;

        chatItem.addEventListener("click", () => {
            activeContactId = contact.id;
            renderChatList(searchInputEl.value);
            renderActiveChat();
        });

        chatListEl.appendChild(chatItem);
    });
}

function renderActiveChat() {
    const activeContact = contacts.find(c => c.id === activeContactId);

    activeUserNameEl.textContent = activeContact.name;
    activeUserAvatarEl.src = activeContact.avatar;
    activeUserStatusEl.textContent = activeContact.status;

    chatMessagesEl.innerHTML = "";
    activeContact.messages.forEach(msg => {
        const msgDiv = document.createElement("div");
        msgDiv.classList.add("message", msg.sender);
        msgDiv.innerHTML = `
            ${msg.text}
            <span class="time">${msg.time}</span>
        `;
        chatMessagesEl.appendChild(msgDiv);
    });

    chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
}

chatFormEl.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = messageInputEl.value.trim();
    if (!text) return;

    const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const activeContact = contacts.find(c => c.id === activeContactId);

    activeContact.messages.push({
        sender: "sent",
        text: text,
        time: currentTime
    });

    messageInputEl.value = "";
    renderActiveChat();
    renderChatList(searchInputEl.value);

    setTimeout(() => {
        activeContact.messages.push({
            sender: "received",
            text: "Mesajınız alındı! Teşekkürler.",
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        });
        renderActiveChat();
        renderChatList(searchInputEl.value);
    }, 1500);
});

searchInputEl.addEventListener("input", (e) => {
    renderChatList(e.target.value);
});

renderChatList();
renderActiveChat();
async function getWeather() {
    const city = document.getElementById('cityInput').value.trim();
    const resultDiv = document.getElementById('weatherResult');

    if (!city) {
        resultDiv.innerHTML = `<p style="color: red;">Lütfen bir şehir adı girin!</p>`;
        return;
    }

    try {
        resultDiv.innerHTML = `<p>Yükleniyor...</p>`;

        const geoGeoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=tr&format=json`;
        const geoResponse = await fetch(geoGeoUrl);
        const geoData = await geoResponse.json();

        if (!geoData.results || geoData.results.length === 0) {
            resultDiv.innerHTML = `<p style="color: red;">Şehir bulunamadı!</p>`;
            return;
        }

        const { latitude, longitude, name, country } = geoData.results[0];

        const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weathercode&timezone=auto`;
        
        const weatherResponse = await fetch(weatherUrl);
        const weatherData = await weatherResponse.json();

        const temp = weatherData.current.temperature_2m;
        const humidity = weatherData.current.relative_humidity_2m;
        const windSpeed = weatherData.current.wind_speed_10m;
        
        resultDiv.innerHTML = `
            <h2>${name}, ${country || ''}</h2>
            <p><strong>Sıcaklık:</strong> ${temp} °C</p>
            <p><strong>Nem:</strong> %${humidity}</p>
            <p><strong>Rüzgar Hızı:</strong> ${windSpeed} km/s</p>
        `;

    } catch (error) {
        console.error("Hata:", error);
        resultDiv.innerHTML = `<p style="color: red;">Veriler alınırken bir hata oluştu.</p>`;
    }
}
const amountInput = document.jsdelivr || document.getElementById("amount"); 
const amountEl = document.getElementById("amount");
const fromCurrencySelect = document.getElementById("fromCurrency");
const toCurrencySelect = document.getElementById("toCurrency");
const resultDisplay = document.getElementById("result");
const rateText = document.getElementById("rateText");
const swapButton = document.getElementById("swapButton");

async function cevir() {
    const miktar = parseFloat(amountEl.value);
    const kaynak = fromCurrencySelect.value;
    const hedef = toCurrencySelect.value;

    if (!miktar || miktar <= 0) {
        resultDisplay.innerText = "0.00";
        return;
    }

    if (kaynak === hedef) {
        resultDisplay.innerText = miktar.toFixed(2);
        rateText.innerText = `1 ${kaynak} = 1.0000 ${hedef}`;
        return;
    }

    try {
        const response = await fetch(`https://open.er-api.com/v6/latest/${kaynak}`);
        
        if (!response.ok) {
            throw new Error("Güncel kur verisi alınamadı!");
        }

        const data = await response.json();
        
        const kurOrani = data.rates[hedef];
        const sonuc = miktar * kurOrani;

        resultDisplay.innerText = sonuc.toFixed(2);
        rateText.innerText = `1 ${kaynak} = ${kurOrani.toFixed(4)} ${hedef}`;

    } catch(error) {
        console.error("Hata:", error);
        resultDisplay.innerText = "Hata!";
    }
}

amountEl.addEventListener("input", cevir);
fromCurrencySelect.addEventListener("change", cevir);
toCurrencySelect.addEventListener("change", cevir);

swapButton.addEventListener("click", () => {
    const temp = fromCurrencySelect.value;
    fromCurrencySelect.value = toCurrencySelect.value;
    toCurrencySelect.value = temp;
    cevir();
});

cevir();
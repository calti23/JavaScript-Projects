const API_URL = "https://api.github.com/users/";

const form = document.getElementById("searchForm");
const searchInput = document.getElementById("usernameInput");
const resultContainer = document.getElementById("resultContainer");

form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = searchInput.value.trim();
    
    if (username) {
        resultContainer.innerHTML = "<p>Loading...</p>";
        await getGitHubUserData(username);
    }
});

async function getGitHubUserData(username) {
    try {
        const userRes = await fetch(API_URL + username);
        if (!userRes.ok) throw new Error("User not found!");
        const userData = await userRes.json();

        const reposRes = await fetch(`${API_URL}${username}/repos?sort=updated&per_page=5`);
        const reposData = await reposRes.json();

        displayProfile(userData, reposData);
    } catch (error) {
        resultContainer.innerHTML = `<p class="error">${error.message}</p>`;
    }
}

function displayProfile(user, repos) {
    const reposList = repos.map(repo => `<li><a href="${repo.html_url}" target="_blank">${repo.name}</a> (⭐ ${repo.stargazers_count})</li>`).join("");

    resultContainer.innerHTML = `
        <div class="card">
            <img src="${user.avatar_url}" alt="${user.login}">
            <h2>${user.name || user.login}</h2>
            <p>${user.bio || "There is no Biography."}</p>
            <p><strong>TFollower:</strong> ${user.followers} | <strong>Following:</strong> ${user.following}</p>
            <p><strong>Public Repo:</strong> ${user.public_repos}</p>
            <h3>Son Repos:</h3>
            <ul>${reposList}</ul>
        </div>
    `;
}
const terminalBody = document.getElementById('terminal-body');
const outputHistory = document.getElementById('output-history');
const commandInput = document.getElementById('command-input');

terminalBody.addEventListener('click', () => {
    commandInput.focus();
});

let commandHistory = [];
let historyIndex = -1;

commandInput.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        const command = commandInput.value.trim();
        if (command !== '') {
            commandHistory.push(command);
            historyIndex = commandHistory.length;
            processCommand(command);
        }
        commandInput.value = '';
    } else if (event.key === 'ArrowUp') {
        if (historyIndex > 0) {
            historyIndex--;
            commandInput.value = commandHistory[historyIndex];
        }
        event.preventDefault();
    } else if (event.key === 'ArrowDown') {
        if (historyIndex < commandHistory.length - 1) {
            historyIndex++;
            commandInput.value = commandHistory[historyIndex];
        } else {
            historyIndex = commandHistory.length;
            commandInput.value = '';
        }
        event.preventDefault();
    }
});

function processCommand(input) {
    const args = input.split(' ');
    const cmd = args[0].toLowerCase();
    const param = args[1];

    const historyItem = document.createElement('div');
    historyItem.classList.add('command-history-item');
    historyItem.innerHTML = `<span style="color: #38bdf8;">guest@terminal:~$</span> ${escapeHTML(input)}`;
    outputHistory.appendChild(historyItem);

    const responseItem = document.createElement('div');
    responseItem.classList.add('command-history-item');

    switch (cmd) {
        case 'yardim':
        case 'help':
            responseItem.innerHTML = `
                Mevcut Komutlar:<br>
                &nbsp;&nbsp;<b>yardim / help</b> - Komut listesini gösterir.<br>
                &nbsp;&nbsp;<b>tarih / date</b> - Güncel tarih ve saati gösterir.<br>
                &nbsp;&nbsp;<b>temizle / clear</b> - Terminal ekranını temizler.<br>
                &nbsp;&nbsp;<b>hakkimda</b> - Sistem geliştiricisi hakkında bilgi verir.<br>
                &nbsp;&nbsp;<b>yazi [metin]</b> - Girdiğiniz metni ekrana yazdırır.<br>
                &nbsp;&nbsp;<b>topla [a] [b]</b> - İki sayıyı toplar.<br>
            `;
            break;

        case 'tarih':
        case 'date':
            const now = new Date();
            responseItem.textContent = `Güncel Tarih ve Saat: ${now.toLocaleString('tr-TR')}`;
            break;

        case 'temizle':
        case 'clear':
            outputHistory.innerHTML = '';
            return; 

        case 'hakkimda':
            responseItem.textContent = "Bu terminal arayüzü JavaScript, HTML ve CSS kullanılarak geliştirilmiş web tabanlı bir simülatördür.";
            break;

        case 'yazi':
            const textToPrint = args.slice(1).join(' ');
            responseItem.textContent = textToPrint ? textToPrint : "Yazdırılacak metin belirtilmedi. (Örn: yazi Merhaba Dünya)";
            break;

        case 'topla':
            const num1 = parseFloat(args[1]);
            const num2 = parseFloat(args[2]);
            if (isNaN(num1) || isNaN(num2)) {
                responseItem.textContent = "Hata: Lütfen geçerli iki sayı girin. (Örn: topla 5 10)";
            } else {
                responseItem.textContent = `Sonuç: ${num1 + num2}`;
            }
            break;

        default:
            responseItem.innerHTML = `Komut bulunamadı: <span style="color: #ff5f56;">${escapeHTML(cmd)}</span>. "yardim" yazarak komutları görebilirsiniz.`;
            break;
    }

    outputHistory.appendChild(responseItem);

    terminalBody.scrollTop = terminalBody.scrollHeight;
}

function escapeHTML(str) {
    return str.replace(/[&<>'"]/g, 
        tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
    );
}